import pandas as pd
import numpy as np
from itertools import combinations

# ---------------------------------------
# Step 1: Load data
# ---------------------------------------

df = pd.read_csv("causal_results.csv")
filtered = pd.read_csv("filtered_rules.csv")

important_events = set(filtered["event_id"].values)

print("Important events used for Level-2:", len(important_events))

# ---------------------------------------
# Step 2: Group by sequence
# ---------------------------------------

grouped = df.groupby("sequence_id")

pair_effects = {}

for seq_id, group in grouped:

    # Keep only important events
    group = group[group["event_id"].isin(important_events)]

    unique_events = group["event_id"].unique()

    # Need at least 2 events
    if len(unique_events) < 2:
        continue

    for a, b in combinations(unique_events, 2):
        key = tuple(sorted([a, b]))

        delta_a = group[group["event_id"] == a]["causal_delta"].mean()
        delta_b = group[group["event_id"] == b]["causal_delta"].mean()

        combined_delta = delta_a + delta_b

        if key not in pair_effects:
            pair_effects[key] = []

        pair_effects[key].append(combined_delta)

# ---------------------------------------
# Step 3: Aggregate pair statistics
# ---------------------------------------

results = []

total_pairs = sum(len(v) for v in pair_effects.values())

for key, deltas in pair_effects.items():
    mean_delta = np.mean(deltas)
    coverage = len(deltas) / total_pairs
    score = mean_delta * coverage

    results.append([
        key[0],
        key[1],
        mean_delta,
        coverage,
        score
    ])

pairs_df = pd.DataFrame(results, columns=[
    "event_A",
    "event_B",
    "mean_causal_effect",
    "coverage",
    "rule_score"
])

pairs_df = pairs_df.sort_values(
    by="rule_score",
    key=abs,
    ascending=False
)

pairs_df.to_csv("level2_rules.csv", index=False)

print("Saved level2_rules.csv")
print("Total Level-2 rules:", len(pairs_df))
print("\nTop 10 Level-2 Rules:")
print(pairs_df.head(10))