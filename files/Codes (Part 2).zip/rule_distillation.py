import pandas as pd
import numpy as np

# --------------------------------------------------
# Step 1: Load causal statistics
# --------------------------------------------------

df = pd.read_csv("causal_results.csv")

total_events = len(df)

print("Total intervention entries:", total_events)

# --------------------------------------------------
# Step 2: Level-1 Rule Aggregation
# Compute:
#   mean causal effect (mu_k)
#   coverage
#   rule score = mu_k * coverage
# --------------------------------------------------

grouped = df.groupby("event_id")

rules = []

for event_id, group in grouped:
    mean_delta = group["causal_delta"].mean()
    count = len(group)
    coverage = count / total_events #frequency of occurence
    score = mean_delta * coverage

    rules.append([
        event_id,
        mean_delta,
        coverage,
        score
    ])

rules_df = pd.DataFrame(rules, columns=[
    "event_id",
    "mean_causal_effect",
    "coverage",
    "rule_score"
])

rules_df = rules_df.sort_values(
    by="rule_score",
    key=abs,
    ascending=False
)

rules_df.to_csv("distilled_rules.csv", index=False)

print("Saved distilled_rules.csv")
print("Total unique events (Level-1 rules):", len(rules_df))

tau = 0.01  # threshold to remove negligible effects
filtered_rules = rules_df[
    np.abs(rules_df["mean_causal_effect"]) > tau
]

filtered_rules = filtered_rules.sort_values(
    by="rule_score",
    key=abs,
    ascending=False
)

filtered_rules.to_csv("filtered_rules.csv", index=False)

print("\nFiltered rules count:", len(filtered_rules))
print("\nTop 10 Filtered Rules:")
print(filtered_rules.head(10))