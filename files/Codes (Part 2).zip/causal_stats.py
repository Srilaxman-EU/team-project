import torch
import pandas as pd
torch.set_num_threads(4)

from utils import load_elo_sequences
from model.lstm_model import LSTMClassifier
from causal.interventions import causal_effect


X, y, vocab = load_elo_sequences(
    "data/train.csv",
    "data/historical_transactions.csv"
)

num_classes = int(torch.unique(y).numel())

embed_dim = 64
hidden_dim = 128
model = LSTMClassifier(len(vocab) + 1, embed_dim, hidden_dim, num_classes)
model.load_state_dict(torch.load("lstm_elo.pt"))
model.eval()

results = []

N = min(500, len(X))  # 500 sequences max

for i in range(N):

    if i % 50 == 0:
        print(f"Processing sequence {i}/{N}")

    seq = X[i]
    valid_pos = (seq != 0).nonzero(as_tuple=True)[0]

    for pos in valid_pos:
        delta = causal_effect(model, seq, pos.item())
        results.append([i, seq[pos].item(), pos.item(), delta])

df = pd.DataFrame(results, columns=[
    "sequence_id",
    "event_id",
    "position",
    "causal_delta"
])

df.to_csv("causal_results.csv", index=False)

print("Saved causal_results.csv")