import pandas as pd

# ----------------------------------------
# Step 1: Load final Level-2 rules
# ----------------------------------------

df = pd.read_csv("final_level2_rules.csv")

readable_rules = []

for _, row in df.iterrows():
    a = int(row["event_A"])
    b = int(row["event_B"])
    mu_ab = row["mu_AB"]
    gain = row["interaction_gain"]

    # Determine direction
    if mu_ab > 0:
        direction = "increases"
    else:
        direction = "decreases"

    rule_text = (
        f"IF transactions include merchant_category_id {a} "
        f"AND merchant_category_id {b}, "
        f"THEN the predicted target score {direction} "
        f"significantly (Δ ≈ {mu_ab:.3f}). "
        f"Interaction gain = {gain:.3f}."
    )

    readable_rules.append([
        a,
        b,
        mu_ab,
        gain,
        rule_text
    ])

readable_df = pd.DataFrame(readable_rules, columns=[
    "event_A",
    "event_B",
    "mu_AB",
    "interaction_gain",
    "rule_text"
])

readable_df.to_csv("human_readable_rules.csv", index=False)

print("\nGenerated Human-Readable Rules:\n")
for r in readable_df["rule_text"].head(10):
    print("-", r)

print("\nSaved as human_readable_rules.csv")