import pandas as pd

# ----------------------------------------
# Step 1: Load interaction analysis
# ----------------------------------------

interaction_df = pd.read_csv("interaction_analysis.csv")

print("Total Level-2 rules before filtering:", len(interaction_df))

# ----------------------------------------
# Step 2: Keep strong super-additive rules
# ----------------------------------------

threshold = 0.1  # interaction gain threshold

strong_rules = interaction_df[
    interaction_df["interaction_gain"] > threshold
]

print("Rules with interaction_gain >", threshold, ":", len(strong_rules))

# ----------------------------------------
# Step 3: Sort by strongest interaction
# ----------------------------------------

strong_rules = strong_rules.sort_values(
    by="interaction_gain",
    ascending=False
)

# ----------------------------------------
# Step 4: Keep Top 20
# ----------------------------------------

top_rules = strong_rules.head(20)

# ----------------------------------------
# Step 5: Save final distilled rules
# ----------------------------------------

top_rules.to_csv("final_level2_rules.csv", index=False)

print("\nFinal Top 20 Level-2 Compositional Rules:")
print(top_rules)
print("\nSaved as final_level2_rules.csv")