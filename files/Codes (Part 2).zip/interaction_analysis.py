import pandas as pd
import numpy as np

# -----------------------------
# Load Level-1 and Level-2
# -----------------------------

level1 = pd.read_csv("filtered_rules.csv")
level2 = pd.read_csv("level2_rules.csv")

# Create lookup dictionary for single effects
mu_lookup = dict(zip(level1["event_id"], level1["mean_causal_effect"]))

results = []

for _, row in level2.iterrows():

    a = row["event_A"]
    b = row["event_B"]
    mu_ab = row["mean_causal_effect"]

    # skip if single not found (should not happen)
    if a not in mu_lookup or b not in mu_lookup:
        continue

    mu_a = mu_lookup[a]
    mu_b = mu_lookup[b]

    interaction_gain = abs(mu_ab) - (abs(mu_a) + abs(mu_b))

    results.append([
        a,
        b,
        mu_a,
        mu_b,
        mu_ab,
        interaction_gain
    ])

interaction_df = pd.DataFrame(results, columns=[
    "event_A",
    "event_B",
    "mu_A",
    "mu_B",
    "mu_AB",
    "interaction_gain"
])

# Sort by strongest positive interaction gain
interaction_df = interaction_df.sort_values(
    by="interaction_gain",
    ascending=False
)

interaction_df.to_csv("interaction_analysis.csv", index=False)

print("Saved interaction_analysis.csv")
print("\nTop 10 Super-Additive Interactions:")
print(interaction_df.head(10))