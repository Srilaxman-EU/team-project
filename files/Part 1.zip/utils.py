import pandas as pd
import torch
from collections import defaultdict

MAX_SEQ_LEN = 30
MAX_CARDS = 5000

def load_elo_sequences(train_path, trans_path):
    train = pd.read_csv(train_path)
    trans = pd.read_csv(trans_path)

    train["label"] = (train["target"] > 0).astype(int)

    print("Transaction columns:", trans.columns.tolist())

    trans = trans.sort_values("purchase_date") #Sort by Purchase_Date

    seqs = defaultdict(list)
    for _, row in trans.iterrows():
        seqs[row["card_id"]].append(row["merchant_category_id"])

    all_events = set(e for s in seqs.values() for e in s)
    vocab = {e: i + 1 for i, e in enumerate(all_events)} #Convert Merchant Ids to Integers

    X, y = [], []
    for _, row in train.iloc[:MAX_CARDS].iterrows():
        cid = row["card_id"]
        if cid not in seqs:
            continue

        s = seqs[cid][-MAX_SEQ_LEN:]
        s = [vocab[e] for e in s]
        s = [0] * (MAX_SEQ_LEN - len(s)) + s #Add 0's for Padding if seq < 30

        X.append(s)
        y.append(row["label"])

    return torch.tensor(X), torch.tensor(y), vocab
