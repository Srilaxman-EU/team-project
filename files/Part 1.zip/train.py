import torch
from torch.utils.data import DataLoader, TensorDataset
from utils import load_elo_sequences
from model.lstm_model import LSTMClassifier
import torch
torch.set_num_threads(4) 


X, y, vocab = load_elo_sequences(
    "data/train.csv",
    "data/historical_transactions.csv"
)

num_classes = int(torch.unique(y).numel()) #Find total labels in the dataset

dataset = TensorDataset(X, y)
loader = DataLoader(dataset, batch_size=32, shuffle=True)


model = LSTMClassifier(len(vocab) + 1, embed_dim, hidden_dim, num_classes)
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

for epoch in range(3):
    total_loss = 0
    for xb, yb in loader:
        optimizer.zero_grad()
        preds = model(xb)
        loss = criterion(preds, yb)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()

    avg_loss = total_loss / len(loader)
    print(f"Epoch {epoch + 1} | Avg Loss: {avg_loss:.4f}")



torch.save(model.state_dict(), "lstm_elo.pt")
